<?php
echo 
'<div id="div_header">
CSS326 System
</div>
<div id="div_subhead">
<ul id="menu">
    <li><a href="user.php">User Profile</a></li>
    <li><a href="add_user.php">Add User</a></li>
    <li><a href="group.php">User Group</a></li>
    <li><a href="add_group.php">Add User Group</a></li>
</ul>
</div>';
?>